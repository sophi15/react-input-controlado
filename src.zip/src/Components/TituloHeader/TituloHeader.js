import { DetalhesTitulo, TituloHeaderContainer } from "./styled"

function TituloHeader(){
    return(
        <TituloHeaderContainer>Some sweets of
            <DetalhesTitulo>Happiness!</DetalhesTitulo>
        </TituloHeaderContainer>

    )


}

export default TituloHeader