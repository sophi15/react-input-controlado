import Card from "../../Components/Card/Card"
import TituloHeader from "../../Components/TituloHeader/TituloHeader"
import Header from "../../Components/Header/Header"
import Nav from "../../Components/Navegar/Nav"
import menu from "../../assets/menu.png"
import lupa from "../../assets/lupa.png"
import { SectionCard } from "./styled"

function Home(props){

    return(
        <>
            <Header 
            pagina={props.pagina}
            imgPrimeira={menu}
            imgSegunda={lupa}
            />
            <TituloHeader/>
            <Nav/>
            <Card/>

            <SectionCard>
                <Card/>
                <Card/>
                <Card/>
            </SectionCard>
        </>

    )

}

export default Home 