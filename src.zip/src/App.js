import Detalhes from "./Page/Detalhes/Detalhes";
import Home from "./Page/Home/Home";
import StyledGlobal, { CorFundo } from "./styledGlobal";
import { useState } from "react";

function App() {
  const [trocarDePagina, setTrocarDePagina] = useState("0")

  const changePage = (change) =>{
    setTrocarDePagina(change)
  }
  return (
      <>
    
      <CorFundo>
        <StyledGlobal />
      {trocarDePagina === "0" ? (
        <Home pagina={()=> changePage("0")}/>
      ) : (
        <Detalhes pagina={()=> changePage("1")}/>
      )}
       

        
      </CorFundo>
      
      </>
    
  );
}

export default App;
